from .otBase import BaseTTXConverter


class table_S_T_A_T_(BaseTTXConverter):
    pass
